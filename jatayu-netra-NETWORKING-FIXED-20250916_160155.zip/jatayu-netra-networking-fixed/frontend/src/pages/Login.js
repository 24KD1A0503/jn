import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import axios from 'axios';

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'tourist'
  });
  const [loading, setLoading] = useState(false);

  // Configure axios base URL for API calls
  const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

  const roles = [
    { value: 'tourist', label: '🧳 Tourist', demo: { username: 'priya_sharma', password: 'Tourist@123' } },
    { value: 'police', label: '👮 Police', demo: { username: 'officer_singh', password: 'Police@789' } },
    { value: 'hospital', label: '🏥 Hospital', demo: { username: 'dr_patel', password: 'Doctor@101' } },
    { value: 'tourism', label: '🏛️ Tourism', demo: { username: 'tourism_admin', password: 'Tourism@202' } }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      console.log('Attempting login to:', `${API_BASE_URL}/api/auth/login`);
      console.log('Login data:', { ...formData, password: '[HIDDEN]' });

      const response = await axios.post(`${API_BASE_URL}/api/auth/login`, formData, {
        timeout: 10000, // 10 second timeout
        headers: {
          'Content-Type': 'application/json'
        }
      });

      console.log('Login response:', response.data);

      if (response.data.success) {
        localStorage.setItem('user', JSON.stringify(response.data.data.user));
        toast.success('Login successful!');
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Login error:', error);
      if (error.code === 'ECONNREFUSED') {
        toast.error('Cannot connect to server. Please ensure backend is running.');
      } else if (error.response) {
        toast.error(error.response.data?.message || 'Login failed');
      } else if (error.request) {
        toast.error('Network error: Cannot reach server');
      } else {
        toast.error('Login failed: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (role) => {
    const roleData = roles.find(r => r.value === role);
    if (roleData) {
      setFormData({ 
        ...roleData.demo, 
        role 
      });
    }
  };

  const testConnection = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/health`);
      toast.success('Backend connection successful!');
      console.log('Backend health:', response.data);
    } catch (error) {
      toast.error('Cannot connect to backend');
      console.error('Connection test failed:', error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-green-50 px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🛡️</div>
          <h1 className="text-3xl font-bold text-gray-900">JatayuNetra</h1>
          <p className="text-gray-600 mt-2">Smart Tourist Safety System</p>
        </div>

        {/* Connection Test Button */}
        <div className="mb-4 text-center">
          <button
            type="button"
            onClick={testConnection}
            className="text-xs bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded"
          >
            Test Backend Connection
          </button>
          <p className="text-xs text-gray-500 mt-1">API: {API_BASE_URL}</p>
        </div>

        {/* Demo Credentials */}
        <div className="mb-6">
          <p className="text-sm text-gray-600 mb-3">Quick Demo Login:</p>
          <div className="grid grid-cols-2 gap-2">
            {roles.map((role) => (
              <button
                key={role.value}
                type="button"
                onClick={() => fillDemo(role.value)}
                className="text-xs p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                {role.label}
              </button>
            ))}
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <select
              value={formData.role}
              onChange={(e) => setFormData({...formData, role: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              {roles.map((role) => (
                <option key={role.value} value={role.value}>
                  {role.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <input
              type="text"
              placeholder="Username"
              value={formData.username}
              onChange={(e) => setFormData({...formData, username: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <div>
            <input
              type="password"
              placeholder="Password"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:bg-blue-300"
          >
            {loading ? 'Signing In...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;