import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import axios from 'axios';

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/login');
      return;
    }
    setUser(JSON.parse(userData));
  }, [navigate]);

  const handleSOS = async () => {
    if (window.confirm('🚨 EMERGENCY SOS ALERT! Are you sure you want to send an SOS signal?')) {
      try {
        const response = await axios.post(`${API_BASE_URL}/api/emergency/sos`, {
          timestamp: new Date().toISOString(),
          location: { lat: 10.0261, lng: 76.3125 },
          type: 'manual'
        });

        if (response.data.success) {
          toast.success('🚨 SOS Alert sent successfully! Help is on the way!');
        }
      } catch (error) {
        console.error('SOS error:', error);
        toast.error('Failed to send SOS alert');
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    toast.success('Logged out successfully');
    navigate('/login');
  };

  if (!user) return <div className="flex items-center justify-center min-h-screen">Loading...</div>;

  const getDashboardContent = () => {
    switch (user.role) {
      case 'tourist':
        return (
          <div className="dashboard-grid">
            <div className="dashboard-card">
              <div className="card-icon">👤</div>
              <div className="card-title">My Profile</div>
              <div className="card-description">Manage personal information and emergency contacts</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">🚗</div>
              <div className="card-title">Vehicle Assistance</div>
              <div className="card-description">Find nearby fuel stations, mechanics, and tire repair</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">🏥</div>
              <div className="card-title">Medical Assistance</div>
              <div className="card-description">Emergency medical help and nearby hospitals</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">👮</div>
              <div className="card-title">Police Assistance</div>
              <div className="card-description">Report incidents and get police help</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">📞</div>
              <div className="card-title">Emergency Contacts</div>
              <div className="card-description">Manage your emergency contact list</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">🗺️</div>
              <div className="card-title">Plan a Trip</div>
              <div className="card-description">Plan safe routes and get travel recommendations</div>
            </div>
          </div>
        );
      case 'police':
        return (
          <div className="dashboard-grid">
            <div className="dashboard-card">
              <div className="card-icon">🚨</div>
              <div className="card-title">SOS Alerts</div>
              <div className="card-description">Monitor and respond to emergency alerts</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">👥</div>
              <div className="card-title">Tourist Records</div>
              <div className="card-description">View tourist information and tracking data</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">📋</div>
              <div className="card-title">E-FIR Generator</div>
              <div className="card-description">Generate electronic FIRs automatically</div>
            </div>
          </div>
        );
      case 'hospital':
        return (
          <div className="dashboard-grid">
            <div className="dashboard-card">
              <div className="card-icon">🚑</div>
              <div className="card-title">Medical Alerts</div>
              <div className="card-description">Receive and respond to medical emergencies</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">👨‍⚕️</div>
              <div className="card-title">Patient Information</div>
              <div className="card-description">Access tourist medical information</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">🚨</div>
              <div className="card-title">Ambulance Dispatch</div>
              <div className="card-description">Coordinate ambulance services</div>
            </div>
          </div>
        );
      case 'tourism':
        return (
          <div className="dashboard-grid">
            <div className="dashboard-card">
              <div className="card-icon">📊</div>
              <div className="card-title">Tourist Analytics</div>
              <div className="card-description">View tourism statistics and trends</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">🗺️</div>
              <div className="card-title">Safety Heatmap</div>
              <div className="card-description">Monitor tourist safety zones and hotspots</div>
            </div>
            <div className="dashboard-card">
              <div className="card-icon">⚠️</div>
              <div className="card-title">Risk Monitoring</div>
              <div className="card-description">Track and assess safety risks in real-time</div>
            </div>
          </div>
        );
      default:
        return <div>Unknown role</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <span className="text-2xl mr-2">🛡️</span>
              <h1 className="text-xl font-bold text-gray-900">JatayuNetra</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">
                Welcome, {user.fullName} ({user.role})
              </span>
              <button
                onClick={handleLogout}
                className="text-sm text-red-600 hover:text-red-800"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              {user.role.charAt(0).toUpperCase() + user.role.slice(1)} Dashboard
            </h2>

            {/* SOS Button - Only for tourists */}
            {user.role === 'tourist' && (
              <div className="mb-8">
                <button
                  onClick={handleSOS}
                  className="sos-button"
                  title="Emergency SOS - Click in case of emergency"
                >
                  🚨 SOS
                </button>
                <p className="text-sm text-gray-600 mt-2">
                  Emergency SOS Button - Click only in case of real emergency
                </p>
              </div>
            )}
          </div>

          {getDashboardContent()}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;